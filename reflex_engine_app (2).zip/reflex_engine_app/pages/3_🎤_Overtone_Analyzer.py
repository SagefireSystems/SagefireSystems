import streamlit as st
import numpy as np
import matplotlib.pyplot as plt
from utils.audio import read_audio_wav, band_energy_db

st.title("🎤 Overtone Analyzer (WAV/FLAC)")
st.caption("Minimal spectral bands: Bass 60–250 Hz • Formant 400–1500 Hz • Overtone 3000–8000 Hz")

st.info("Upload a short **WAV** (recommended 10–30s). MP3 needs extra packages; use WAV for now.")

file = st.file_uploader("Upload audio", type=["wav", "flac", "WAV", "FLAC"])
if file is not None:
    try:
        sr, x = read_audio_wav(file.read())
    except Exception as e:
        st.error(f"Could not read audio: {e}")
        st.stop()

    # Trim to first 30s for speed
    max_len = min(len(x), int(sr*30))
    x = x[:max_len]

    # Normalize
    x = x / (np.max(np.abs(x)) + 1e-9)

    # Plot waveform
    t = np.arange(len(x)) / sr
    fig = plt.figure()
    plt.plot(t, x)
    plt.xlabel("Time (s)")
    plt.ylabel("Amplitude")
    plt.title("Waveform (normalized)")
    st.pyplot(fig)

    # Compute band energies (dB rel to total)
    b_db = band_energy_db(x, sr, 60, 250)
    f_db = band_energy_db(x, sr, 400, 1500)
    o_db = band_energy_db(x, sr, 3000, 8000)

    st.subheader("Band Balance (dB relative)")
    st.write({ "Bass_60_250": round(b_db, 1), "Formant_400_1500": round(f_db, 1), "Overtone_3000_8000": round(o_db, 1) })

    # Simple guidance
    st.markdown("### Guidance")
    target = {"Bass": -6, "Formant": -10, "Overtone": -16}
    st.markdown(
        """
**Heuristic target ratios (example starting point):**
- Bass ~ **-6 dB**
- Formant ~ **-10 dB**
- Overtone ~ **-16 dB**

Use this **only** as a directional compass — tune by ear.
        """
    )

    # Bar chart
    fig2 = plt.figure()
    cats = ["Bass (60–250)", "Formant (400–1500)", "Overtone (3k–8k)"]
    vals = [b_db, f_db, o_db]
    plt.bar(cats, vals)
    plt.ylabel("dB (rel to total)")
    plt.title("Band Energy Balance")
    st.pyplot(fig2)

    # Suggestions
    tips = []
    if b_db < -12:
        tips.append("Bass looks light — try a gentle low‑shelf +2 to +4 dB around 120 Hz.")
    if f_db < -14:
        tips.append("Formants look light — add presence around 800–1200 Hz, or reduce enhancers that mask mids.")
    if o_db > -10:
        tips.append("Overtones look hot — consider a narrow cut around the strongest harmonic or reduce exciter/air band.")
    if not tips:
        tips.append("Balance looks reasonable. Fine‑tune by ear and mic technique.")

    st.markdown("### Suggestions")
    for t in tips:
        st.write("• " + t)
