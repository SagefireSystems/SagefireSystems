import streamlit as st
import pandas as pd
from datetime import datetime

st.title("🧠 Daily Workflow")

st.markdown(
    """
A lightweight planner + log. Save your focus goals and quick notes.
Data saves to a local CSV (`data_daily.csv`) in your app directory.
    """
)

with st.form("daily_form"):
    date = st.date_input("Date", value=datetime.now())
    focus = st.text_area("Top 3 Focus Items (one per line)", height=120, placeholder="1) ...\n2) ...\n3) ...")
    blockers = st.text_area("Blockers / Risks", placeholder="What could derail today?")
    gratitude = st.text_area("Gratitude / Wins", placeholder="Small wins count.")
    submitted = st.form_submit_button("Save Entry")

if submitted:
    df_row = pd.DataFrame([{
        "date": date.isoformat(),
        "focus": focus,
        "blockers": blockers,
        "gratitude": gratitude,
        "ts": datetime.now().isoformat(timespec="seconds"),
    }])
    try:
        old = pd.read_csv("data_daily.csv")
        new = pd.concat([old, df_row], ignore_index=True)
    except FileNotFoundError:
        new = df_row
    new.to_csv("data_daily.csv", index=False)
    st.success("Saved to data_daily.csv")
    st.dataframe(new.tail(5), use_container_width=True)
