import streamlit as st
from datetime import datetime
import io

st.title("📦 Obsidian Exporter")

st.markdown(
    """
Generate an Obsidian‑ready Markdown note with **YAML front matter** and numbered sections.
Download the file and drop it into your vault.
    """
)

title = st.text_input("Title", value="Reflex Engine — Daily Log")
tags = st.text_input("Tags (comma-separated)", value="reflex, workflow, log")
aliases = st.text_input("Aliases (comma-separated)", value="RE Log, Reflex Daily")
summary = st.text_area("Summary (1–3 sentences)", value="A quick capture of today’s aims, notes, and outcomes.")

sections = {
    "1) Purpose": st.text_area("1) Purpose", value="Capture and review the day’s objectives and reflections."),
    "2) Highlights": st.text_area("2) Highlights", value="- ...\n- ..."),
    "3) Notes": st.text_area("3) Notes", value="- ..."),
    "4) Actions": st.text_area("4) Actions", value="- [ ] ..."),
    "5) Reality Check": st.text_area("5) Reality Check", value="What’s the blunt truth? What matters next?"),
}

if st.button("Generate Markdown"):
    now = datetime.now().strftime("%Y-%m-%d")
    yaml = f"""---
title: {title}
date: {now}
tags: [{', '.join(t.strip() for t in tags.split(','))}]
aliases: [{', '.join(a.strip() for a in aliases.split(','))}]
---
"""
    body = ["## 🧠 Summary", summary, ""]
    for k, v in sections.items():
        body.append(f"## {k}")
        body.append(v)
        body.append("")
    md = yaml + "\n".join(body)

    bio = io.BytesIO(md.encode("utf-8"))
    st.download_button(
        "⬇️ Download Markdown",
        data=bio,
        file_name=f"{title.replace(' ', '_')}.md",
        mime="text/markdown"
    )
    st.code(md, language="markdown")
