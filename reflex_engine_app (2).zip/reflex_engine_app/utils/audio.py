import numpy as np
from scipy.io import wavfile

def read_audio_wav(file_bytes):
    """Return sr (int) and mono float32 waveform in [-1, 1]."""
    import io
    by = io.BytesIO(file_bytes)
    sr, data = wavfile.read(by)
    # Convert to float32 mono
    if data.dtype == np.int16:
        x = data.astype(np.float32) / 32768.0
    elif data.dtype == np.int32:
        x = data.astype(np.float32) / 2147483648.0
    elif data.dtype == np.float32:
        x = data.astype(np.float32)
    else:
        x = data.astype(np.float32)

    if x.ndim == 2:
        x = x.mean(axis=1)
    return sr, x

def band_energy_db(x, sr, f_lo, f_hi):
    """Compute energy in [f_lo, f_hi] Hz band in dB relative to full-band RMS."""
    # FFT-based bandpass energy estimate
    n = int(2**np.ceil(np.log2(len(x))))
    X = np.fft.rfft(x, n=n)
    freqs = np.fft.rfftfreq(n, d=1/sr)
    # magnitude spectrum
    mag = np.abs(X)
    # simple energy proxy: sum of squared magnitudes in band
    band_mask = (freqs >= f_lo) & (freqs < f_hi)
    band_energy = np.sum(mag[band_mask]**2) + 1e-12
    total_energy = np.sum(mag**2) + 1e-12
    db = 10*np.log10(band_energy / total_energy)
    return float(db)
