# Reflex Engine (Streamlit Starter)

A minimal **human–AI workflow cockpit** you can run locally or deploy fast.

## 🚀 Quickstart (Local)

1) **Install Python 3.10+** (3.11 recommended).  
2) Create and activate a virtual environment:
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
```
3) Install deps:
```bash
pip install -r requirements.txt
```
4) Run the app:
```bash
streamlit run app.py
```
It will open at `http://localhost:8501`.

## 🧱 Project Layout

```
reflex_engine_app/
├─ app.py
├─ pages/
│  ├─ 1_🧠_Daily_Workflow.py
│  ├─ 2_📦_Obsidian_Exporter.py
│  └─ 3_🎤_Overtone_Analyzer.py
├─ utils/
│  └─ audio.py
├─ .streamlit/
│  └─ secrets.toml (optional)
├─ requirements.txt
└─ README.md
```

## 🔐 Secrets (optional)

If you later add LLMs or APIs, put keys in `.streamlit/secrets.toml`:
```toml
OPENAI_API_KEY = "sk-..."
ANTHROPIC_API_KEY = "anthropic-..."
```
Access them in code:
```python
import streamlit as st
openai_key = st.secrets.get("OPENAI_API_KEY", None)
```

## 🎤 Overtone Analyzer Notes

- Supports **WAV/FLAC** for now (MP3 would require extra packages).  
- Computes relative band energies:
  - Bass: 60–250 Hz
  - Formant: 400–1500 Hz
  - Overtone: 3000–8000 Hz
- Use the numbers as **rough guidance** — always trust your ears.

## ☁️ Deploy Options

- **Streamlit Community Cloud**: push to GitHub and click “New app”.
- **Hugging Face Spaces** (Streamlit template).
- **Fly.io / Render / Railway**: containerize with a simple Dockerfile.

## 🧩 Customize

- Add more pages under `pages/` (they auto-appear in the sidebar).
- Extend the analyzer (spectrograms, pitch tracking) using `librosa` if desired.
- Hook up Obsidian exports to your preferred YAML schema.
- Replace text with your **Reflex Engine** terminology and assets.

---

Made for rapid iteration. Keep what serves you, toss what doesn’t.
