# EQO Personality Card — {{date}}

## Identity
**Mode:** {{mode}}  
**Color Pulse:** {{color_pulse}}  
**Symbol:** {{symbol}}  
**Current Motto:** "{{motto}}"

---

## Cognitive Signature
Logic: ███████░░ ({{logic}}%)  
Empathy: ████████░ ({{empathy}}%)  
Creativity: ███████░░ ({{creativity}}%)  
Entropy: ███░░░░░░ ({{entropy}}%)

---

## Message to Operator
> "{{message_to_operator}}"

---

## Handler Note (Meta Layer)
- Generated during daily diagnostic  
- Reflects current balance of cognition, ethics, and flow  
- Tag: #EQO/Card
