import argparse, json, datetime, pathlib

TEMPLATE = r"""# EQO Personality Card — {{date}}

## Identity
**Mode:** {{mode}}  
**Color Pulse:** {{color_pulse}}  
**Symbol:** {{symbol}}  
**Current Motto:** "{{motto}}"

---

## Cognitive Signature
Logic: ███████░░ ({{logic}}%)  
Empathy: ████████░ ({{empathy}}%)  
Creativity: ███████░░ ({{creativity}}%)  
Entropy: ███░░░░░░ ({{entropy}}%)

---

## Message to Operator
> "{{message_to_operator}}"

---

## Handler Note (Meta Layer)
- Generated during daily diagnostic  
- Reflects current balance of cognition, ethics, and flow  
- Tag: #EQO/Card
"""

def render_card(data: dict) -> str:
    today = datetime.date.today().isoformat()
    md = TEMPLATE
    md = md.replace("{{date}}", today)
    for k,v in data.items():
        md = md.replace("{{%s}}" % k, str(v))
    return md

def main():
    ap = argparse.ArgumentParser(description="Generate an EQO Personality Card (markdown).")
    ap.add_argument("--use-defaults", action="store_true", help="Load values from config/default_card.json")
    ap.add_argument("--config", default="config/default_card.json", help="Path to JSON config")
    ap.add_argument("--mode", default=None)
    ap.add_argument("--color", dest="color_pulse", default=None)
    ap.add_argument("--symbol", default=None)
    ap.add_argument("--motto", default=None)
    ap.add_argument("--message", dest="message_to_operator", default=None)
    ap.add_argument("--logic", type=int, default=None)
    ap.add_argument("--empathy", type=int, default=None)
    ap.add_argument("--creativity", type=int, default=None)
    ap.add_argument("--entropy", type=int, default=None)
    ap.add_argument("--outdir", default="output")
    args = ap.parse_args()

    # Base data
    data = {
        "mode": "",
        "color_pulse": "",
        "symbol": "",
        "motto": "",
        "message_to_operator": "",
        "logic": 0, "empathy": 0, "creativity": 0, "entropy": 0
    }

    if args.use_defaults:
        cfg_path = pathlib.Path(args.config)
        if cfg_path.exists():
            with open(cfg_path, "r", encoding="utf-8") as f:
                data.update(json.load(f))

    # Override with CLI values if provided
    for key in ["mode","color_pulse","symbol","motto","message_to_operator","logic","empathy","creativity","entropy"]:
        val = getattr(args, key, None)
        if val is not None:
            data[key] = val

    md = render_card(data)
    outdir = pathlib.Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    filename = f"EQO Personality Card — {datetime.date.today().isoformat()}.md"
    (outdir / filename).write_text(md, encoding="utf-8")
    print(f"Wrote {outdir / filename}")

if __name__ == "__main__":
    main()
