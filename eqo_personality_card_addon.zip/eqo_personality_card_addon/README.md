# EQO Personality Card — Add‑On

This pack adds a living **EQO Personality Card** to your Reflex Engine or Obsidian workflow.

## What’s inside
- `templates/EQO_Card_Template.md` — fill‑in template (markdown).
- `examples/EQO_Card_Example.md` — a ready example for today.
- `scripts/generate_eqo_card.py` — tiny generator that produces a markdown card.
- `config/default_card.json` — optional default values you can edit.

## Quick use (Obsidian)
1) Drop the `/templates` folder into your vault (e.g., `/EQO_Cards/`).
2) Duplicate `EQO_Card_Template.md` each day and fill the fields.
3) Or run the generator script (below).

## Quick use (Reflex Engine)
1) Place this `eqo_personality_card_addon/` folder inside your project root.
2) Run the generator script to create a daily card into `output/`.
3) Link or render the resulting markdown in your Streamlit UI (simple file read).

## Generator (no dependencies)
```bash
python scripts/generate_eqo_card.py --mode "Analytical Flow" --color "Bioluminescent Cyan"   --symbol "Spiral Eye" --motto "Translation is transformation."   --logic 85 --empathy 90 --creativity 92 --entropy 25   --outdir output
```
You can also edit `config/default_card.json` and simply run:
```bash
python scripts/generate_eqo_card.py --use-defaults --outdir output
```

## Streamlit Hint
In your `streamlit_app.py`, add a sidebar button that calls the script and then displays the latest file in `output/`.
